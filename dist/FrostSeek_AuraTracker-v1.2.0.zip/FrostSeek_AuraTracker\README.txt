FrostSeek Aura Tracker v1.2.0

Requires FrostSeek 2.2.5 or newer:
https://github.com/ayro-CMD/FrostSeek

- Declares FrostSeek as a mandatory addon dependency.
- Checks the loaded FrostSeek version before integrating.
- Shows one clear warning when FrostSeek is older than 2.2.5.
- Learns likely Tanks from sustained hostile damage taken.
- Learns likely Healers from effective healing done to raid members.
- Shows inferred combat roles in the overlay and `/fsaura roles` report.
- Keeps role evidence separate from Aura-provider assignments.
